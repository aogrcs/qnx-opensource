QNX Neutrino 6.5.0 BSP for ti-beaglebone 1.0.0
Build: 201201171458
For documentation related to this BSP, please refer to the pages dedicated to this BSP on the Foundry27
http://community.qnx.com/sf/wiki/do/viewPage/projects.bsp/wiki/BSPAndDrivers
