/*
 * THIS FILE WAS GENERATED AUTOMATICALLY
 *   -- THIS FILE SHOULD NOT BE CHANGED BY YOUR HANDS.
 */
#if (!(defined(__XTTVERSION_H)))
# define __XTTVERSION_H   0x010300

# define _XTT_V_MAJOR     1
# define _XTT_V_MINOR     3
# define _XTT_V_REVISION  1
# define _XTT_VENDOR_NAME "X-TrueType Server Project"
# define _XTT_RELEASE_NAME \
    "===X-TT-ID: X-TrueType Server Version 1.3 [Aoi MATSUBARA Release 3] ==="

#endif

/* end of file */
